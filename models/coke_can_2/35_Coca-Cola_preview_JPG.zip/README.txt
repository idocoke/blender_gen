Thank you for purchasing model+model products.

1. INTRODUCTION

Model+model creates for you high quality 3d models. Now you can easily add more details to your scenes and greatly save your time. Model+model also gives you the opportunity to choose whether to buy a single model or purchase a large number of models in one volume at a very attractive price. All our models are available in different formats with all textures. 

2. HOW TO USE

We do our best to make all products simple to use. The name of any file contains the volume number, the product number and some description. For example mpm_vol.09_p03_vray.MAX means the product number 3 from volume 9 prepared for use in *.max scenes with vray rendering system. Available materials are Scanline, V-Ray and Mental Ray A&D. V-Ray materials are available in gamma 1.0 and 2.2.

3. LICENSE AGREEMENT

All digital products (including free and promotional products) and files that accompany it, such as textures or images are the property of model+model and cannot be resold, assigned, published or otherwise redistributed. Models or textures can be modified in any way in order to conform them to your needs. However, any such modifications are still derivatives of the original and cannot be sold or distributed. You may use products for private or commercial use only if one of the following is applicable:
- the product was bought by you via model+model or partner website; 
- the product is free and was downloaded from model+model or partner website;
- the product was granted to you by modelplusmodel for promotional or other purposes.
The list of partner websites available on request by email. 

4. CONTACT US

We very much appreciate your opinion on model+model products and are always waiting for your ideas about future products. Please send any feedback to support@modelplusmodel.com or use the contact form on our website.
Thank you.

model+model
www.modelplusmodel.com